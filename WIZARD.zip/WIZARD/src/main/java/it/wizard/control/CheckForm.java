package it.wizard.control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CheckForm")
public class CheckForm extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String error= "";
		String nome=request.getParameter("nome");
		String cognome=request.getParameter("cognome");
		String cell =request.getParameter("cell");
		String indirizzo=request.getParameter("indirizzo");
		String città=request.getParameter("città");
		
		if(nome== null || nome.trim().equals("")) {
			error+="Inserisci il nome <br>";
		} else {
			request.setAttribute("nome", nome);
		}
		
		if(cognome== null || cognome.trim().equals("")) {
			error+="Inserisci il cognome<br>";
		} else {
			request.setAttribute("cognome", cognome);
		}
		
		if(cell== null || cell.trim().equals("")) {
			error+="Inserisci il recapito telefonico<br>";
		} else {
			request.setAttribute("cell", cell);
		}
		
		if(indirizzo== null || indirizzo.trim().equals("")) {
			error+="Inserisci l'indirizzo<br>";
		} else {
			request.setAttribute("indirizzo", indirizzo);
		}
		
		if(città== null || città.trim().equals("")) {
			error+="Inserisci la città <br>";
		} else {
			request.setAttribute("città", città);
		}
		
		if(error != null && !error.equals("")) {
            request.setAttribute("error", error);
        } else {
            String message = "Nome:"+nome+" Cognome:"+cognome+ "Cellulare:"+cell+ "Indirizzo:"+indirizzo+"Città:"+città;
            request.setAttribute("message", message);
        }
		
		RequestDispatcher dispatcher= getServletContext().getRequestDispatcher("/CheckForm.jsp");
		dispatcher.forward(request, response);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
				doGet(request, response);
	}

}
