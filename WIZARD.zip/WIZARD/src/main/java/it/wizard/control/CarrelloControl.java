package it.wizard.control;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import it.wizard.model.Carrello;
import it.wizard.model.ProductBean;
import it.wizard.model.ProductModelDS;

@WebServlet("/CarrelloControl")
public class CarrelloControl extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public CarrelloControl() {
        super();
        // TODO Auto-generated constructor stub
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        System.out.println("sei qui 1");
        
        String action = request.getParameter("action");

        Carrello carrello = (Carrello) request.getSession().getAttribute("carrello");

        if (action.equals("aggiungi")) {

            String id_prodotto = request.getParameter("id_prodotto");

            ProductModelDS prodmod = new ProductModelDS();

            try {
                ProductBean prodotto = new ProductBean();
                prodotto = prodmod.doRetrieveByKey(id_prodotto);
                if (carrello == null) {
                    carrello = new Carrello();
                }
                carrello.addProduct(prodotto);
                 request.getSession().removeAttribute("carrello");
                 request.getSession().setAttribute("carrello", carrello);

                 response.sendRedirect(response.encodeRedirectURL("./carrello.jsp"));

            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        doGet(request, response);

    }

}