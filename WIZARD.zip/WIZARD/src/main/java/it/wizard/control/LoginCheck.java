package it.wizard.control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import it.wizard.model.LoginModel;
import it.wizard.model.UtenteBean;

@WebServlet("/LoginCheck")
public class LoginCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LoginCheck() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//String errore = null;
	
		String username = (String) request.getParameter("username");
		String password = (String) request.getParameter("password");
		DataSource ds = (DataSource) getServletContext().getAttribute("DataSource");
		LoginModel login = new LoginModel(ds);
		UtenteBean utente = new UtenteBean();
		int x = utente.getTipologia();
		
		try {
			utente = login.cercaUtente(username, password);
			
		} catch (SQLException e) {
			System.out.println("Eccezione login utente");
			e.printStackTrace();	
		}
		x=utente.getTipologia();
		if (x==0 || x==1) {
			HttpSession sessione = request.getSession(true); // restituisce la sessione se esiste, altrimenti la crea
															// nuova
			sessione.setAttribute("utente", utente);
			System.out.println("La sessione è: " +utente);
			
			// String index1 = response.encodeURL("/Index.jsp"); //URL rewriting
			// System.out.println(index1);
			if (x==0) {
				getServletContext().getRequestDispatcher("/Home.jsp").forward(request, response); 	
			}
																									
			else if (x==1) 
				getServletContext().getRequestDispatcher("/paginaAdmin.jsp").forward(request, response);
				
				
		 else {
			//response.sendRedirect("login.jsp");
		}
		
	}
}
}
