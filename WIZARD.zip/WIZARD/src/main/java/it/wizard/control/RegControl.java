package it.wizard.control;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import it.wizard.model.RegistrazioneModel;
import it.wizard.model.UtenteBean;


@WebServlet("/RegControl")
public class RegControl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		RegistrazioneModel model= new RegistrazioneModel();
		UtenteBean utente= new UtenteBean();
		utente.setNome(request.getParameter("nome"));
		utente.setCognome(request.getParameter("cognome"));
		utente.setData_nascita(request.getParameter("datanascita"));
		utente.setIndirizzo(request.getParameter("indirizzo"));
		utente.setCittà(request.getParameter("città"));
		utente.setTipologia(Integer.parseInt(request.getParameter("tipologia")));
		utente.setUsername(request.getParameter("username"));
		utente.setPassword_(request.getParameter("password"));
		utente.setNum_telefono(request.getParameter("cell"));
		
		try {
			model.doSave(utente);
		} catch (SQLException e) {
			System.out.println("errore salvataggio utente");
			e.printStackTrace();
		}
		
		getServletContext().getRequestDispatcher("/ProcessoreView.jsp").forward(request, response);
		
	}

}
