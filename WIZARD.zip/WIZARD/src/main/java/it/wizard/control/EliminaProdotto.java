package it.wizard.control;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import it.wizard.model.Carrello;
import it.wizard.model.ProductBean;
import it.wizard.model.ProductModelDS;


@WebServlet("/EliminaProdotto")
public class EliminaProdotto extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public EliminaProdotto() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String action = request.getParameter("action");
		if (action.equals("elimina")) {
			
			String id_prodotto = request.getParameter("id_prodotto");
			ProductModelDS prodmod = new ProductModelDS();
			
			Carrello carrello = new Carrello();
			HttpSession sessione = request.getSession(false);
			if (sessione != null)
			{
				 carrello = (Carrello) sessione.getAttribute("carrello");
			}
			
			try {
                ProductBean prodotto = new ProductBean();
                prodotto = prodmod.doRetrieveByKey(id_prodotto);

                carrello.removeProduct(prodotto);
                request.getSession().removeAttribute("carrello");
                request.getSession().setAttribute("carrello", carrello);
                 response.sendRedirect(response.encodeRedirectURL("./carrello.jsp"));
            } catch (Exception e) {
                e.printStackTrace();
            }
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
