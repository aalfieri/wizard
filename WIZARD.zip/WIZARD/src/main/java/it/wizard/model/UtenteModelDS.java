package it.wizard.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import javax.sql.DataSource;

import it.wizard.utils.Utility;

public class UtenteModelDS implements UtenteModel<UtenteBean> {
    
    private DataSource ds = null;

    public UtenteModelDS(DataSource ds) {
        this.ds = ds;
    }
    
    @Override
    public Collection<UtenteBean> doRetrieveAll(String order) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        String selectSQL = "SELECT * FROM UTENTE";

        if (order != null && !order.equals("")) {
            selectSQL += "ORDER BY " + order;
        }

        Collection<UtenteBean> utente = new LinkedList<UtenteBean>();

        try {
            connection = ds.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);

            Utility.print("doRetrieveAll " + preparedStatement.toString());

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                UtenteBean bean = new UtenteBean();

                bean.setID_utente(rs.getInt("ID_utente"));
                bean.setNome(rs.getString("Nome"));
                bean.setCognome(rs.getString("Cognome"));
                bean.setData_nascita(rs.getString("Data_nascita"));
                bean.setNum_telefono(rs.getString("Num_telefono"));
                bean.setCittà(rs.getString("Città"));
                bean.setTipologia(rs.getInt("Tipologia"));
                bean.setUsername(rs.getString("Username"));
                bean.setPassword_(rs.getString("Password_"));
                utente.add(bean);
            }

        } finally {
            try {
            if (preparedStatement != null)
                preparedStatement.close();
            }finally {
            if (connection != null)
                connection.close();
            }
        }

        return utente;
    }

    @Override
    public void doSave(UtenteBean item) throws SQLException {
        // TODO Auto-generated method stub

    }

    @Override
    public void doUpdate(UtenteBean item) throws SQLException {
        // TODO Auto-generated method stub

    }

    @Override
    public void doDelete(UtenteBean item) throws SQLException {
        // TODO Auto-generated method stub

    }
    
    @Override
    public UtenteBean doRetrieveByKey(String ID_utente) throws SQLException {
        // TODO Auto-generated method stub
        return null;
    }


}
