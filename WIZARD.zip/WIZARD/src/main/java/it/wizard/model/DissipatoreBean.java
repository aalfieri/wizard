package it.wizard.model;

import java.io.Serializable;

public class DissipatoreBean extends ProductBean {

	private static final long serialVersionUID = 1L;

	
	String ID_dissipatore;
	String Tipo;
	String CPU_compatibile;
	String Socket_compatibile;
	int Num_ventole;
	String Speed_ventole;
	String ID_prodotto;
	
	public DissipatoreBean() {
		
		
		ID_dissipatore= "";
		Tipo= "";
		CPU_compatibile= "";
		Socket_compatibile= "";
		Num_ventole = 0;
		Speed_ventole= "";
		ID_prodotto= "";
	}

	
	
	
	public String getID_dissipatore() {
		return ID_dissipatore;
	}

	public void setID_dissipatore(String iD_dissipatore) {
		ID_dissipatore = iD_dissipatore;
	}

	public String getTipo() {
		return Tipo;
	}

	public void setTipo(String tipo) {
		Tipo = tipo;
	}

	public String getCPU_compatibile() {
		return CPU_compatibile;
	}

	public void setCPU_compatibile(String cPU_compatibile) {
		CPU_compatibile = cPU_compatibile;
	}

	public String getSocket_compatibile() {
		return Socket_compatibile;
	}

	public void setSocket_compatibile(String socket_compatibile) {
		Socket_compatibile = socket_compatibile;
	}

	public int getNum_ventole() {
		return Num_ventole;
	}

	public void setNum_ventole(int num_ventole) {
		Num_ventole = num_ventole;
	}

	public String getSpeed_ventole() {
		return Speed_ventole;
	}

	public void setSpeed_ventole(String speed_ventole) {
		Speed_ventole = speed_ventole;
	}

	public String getID_prodotto() {
		return ID_prodotto;
	}

	public void setID_prodotto(String iD_prodotto) {
		ID_prodotto = iD_prodotto;
	}
	
	@Override
	public boolean equals(Object other) {
		return this.getID_dissipatore() == ((DissipatoreBean) other).getID_dissipatore();
	}
	
	@Override
	public String toString() {
		return ID_dissipatore +", " + Tipo + ", " + CPU_compatibile + ", " + Socket_compatibile + ", " + Num_ventole + ", " + Speed_ventole + "," + ID_prodotto;  
	}
}
