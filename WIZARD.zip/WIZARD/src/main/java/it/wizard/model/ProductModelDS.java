package it.wizard.model;

import java.beans.Beans;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import javax.sql.DataSource;

import it.wizard.utils.Utility;

public class ProductModelDS implements ProductModel<ProductBean> {


	

	@Override
	public Collection<ProductBean> doRetrieveAll(String order) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String selectSQL = "SELECT * FROM PRODOTTO";

		if (order != null && !order.equals("")) {
			selectSQL += "ORDER BY " + order;
		}

		Collection<ProductBean> products = new LinkedList<ProductBean>();

		try {
			connection =DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			Utility.print("doRetrieveAll " + preparedStatement.toString());

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				ProductBean bean = new ProductBean();

				bean.setID_prodotto(rs.getString("ID_prodotto"));
				bean.setID_magazzino(rs.getString("ID_magazzino"));
				bean.setNome(rs.getString("Nome"));
				bean.setBrand(rs.getString("Brand"));
				bean.setQuantita(rs.getInt("Quantita"));
				bean.setPrezzo(rs.getFloat("Prezzo"));
				bean.setDescrizione(rs.getString("Descrizione"));

				products.add(bean);
			}

		} finally {
			try {
			if (preparedStatement != null)
				preparedStatement.close();
			}finally {
			if (connection != null)
				connection.close();
			}
		}

		return products;
	}
	
	@Override
	public ProductBean doRetrieveByKey(String ID_prodotto) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String selectSQL = "SELECT * FROM PRODOTTO WHERE ID_prodotto="+ID_prodotto;

		ProductBean bean = new ProductBean();

		try {
			connection =DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			Utility.print("doRetrieveByKey " + preparedStatement.toString());

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				

				bean.setID_prodotto(rs.getString("ID_prodotto"));
				bean.setID_magazzino(rs.getString("ID_magazzino"));
				bean.setNome(rs.getString("Nome"));
				bean.setBrand(rs.getString("Brand"));
				bean.setQuantita(rs.getInt("Quantita"));
				bean.setPrezzo(rs.getFloat("Prezzo"));
				bean.setDescrizione(rs.getString("Descrizione"));

				
			}

		} finally {
			try {
			if (preparedStatement != null)
				preparedStatement.close();
			}finally {
			if (connection != null)
				connection.close();
			}
		}

		return bean;
	}

	@Override
	public void doSave(ProductBean item) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doUpdate(ProductBean item) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doDelete(ProductBean item) throws SQLException {
		// TODO Auto-generated method stub

	}

}
