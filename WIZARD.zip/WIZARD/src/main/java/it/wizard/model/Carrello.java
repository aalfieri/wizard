package it.wizard.model;

import java.util.ArrayList;

public class Carrello {

    private ArrayList<ProductBean> Carrello;

    String id_cliente;
    float prezzo;

    public Carrello (){
        Carrello = new ArrayList<>();
        id_cliente ="";
        prezzo=-1;
    }

    public String getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(String id_cliente) {
        this.id_cliente = id_cliente;
    }

    public float getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(float prezzo) {
        this.prezzo = prezzo;
    }

    public ArrayList<ProductBean> getCarrello() {
        return Carrello;
    }

    public void setCarrello(ArrayList<ProductBean> carrello) {
        Carrello = carrello;
    }

    public void addProduct(ProductBean prod) {
        Carrello.add(prod);
    }

    public void removeProduct(ProductBean prod) {
        Carrello.remove(prod);
    }

    public int getQuantita() {
        return Carrello.size();
    }


}
