package it.wizard.model;

import java.beans.Beans;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import javax.sql.DataSource;

import it.wizard.utils.Utility;

public class RamModelDS implements RamModel<RAMbean> {



    @Override
    public Collection<RAMbean> doRetrieveAll(String order) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        String selectSQL = "SELECT * FROM RAM,PRODOTTO WHERE PRODOTTO.ID_prodotto= RAM.ID_prodotto";

        if (order != null && !order.equals("")) {
            selectSQL += "ORDER BY " + order;
        }

        Collection<RAMbean> RAM = new LinkedList<RAMbean>();

        try {
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);

            Utility.print("doRetrieveAll " + preparedStatement.toString());

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                RAMbean bean = new RAMbean();
                bean.setID_prodotto(rs.getString("ID_prodotto"));
                bean.setNome(rs.getString("Nome"));
                bean.setBrand(rs.getString("Brand"));
                bean.setQuantita(rs.getInt("Quantita"));
                bean.setPrezzo(rs.getFloat("Prezzo"));
                bean.setDescrizione(rs.getString("Descrizione"));
                bean.setID_ram(rs.getString("ID_ram"));
                bean.setMemoria(rs.getString("Memoria"));
                bean.setForma(rs.getString("Forma"));
                bean.setLatenza(rs.getString("Latenza"));
                bean.setTipo(rs.getString("Tipo"));
                bean.setVelocita(rs.getString("Velocita"));
                bean.setModello(rs.getString("Modello"));
                RAM.add(bean);
            }

        } finally {
            try {
            if (preparedStatement != null)
                preparedStatement.close();
            }finally {
            if (connection != null)
                connection.close();
            }
        }

        return RAM;
    }

    @Override
    public RAMbean doRetrieveByKey(String ID_ram) throws SQLException {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void doSave(RAMbean item) throws SQLException {
        // TODO Auto-generated method stub

    }

    @Override
    public void doUpdate(RAMbean item) throws SQLException {
        // TODO Auto-generated method stub

    }

    @Override
    public void doDelete(RAMbean item) throws SQLException {
        // TODO Auto-generated method stub

    }

}