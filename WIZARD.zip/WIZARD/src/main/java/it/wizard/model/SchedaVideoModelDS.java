package it.wizard.model;

import java.beans.Beans;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import javax.sql.DataSource;

import it.wizard.utils.Utility;

public class SchedaVideoModelDS implements SchedaVideoModel<Scheda_VideoBean> {


	@Override
	public Collection<Scheda_VideoBean> doRetrieveAll(String order) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String selectSQL = "SELECT * FROM SCHEDA_VIDEO,PRODOTTO where PRODOTTO.ID_prodotto=SCHEDA_VIDEO.ID_prodotto";

		if (order != null && !order.equals("")) {
			selectSQL += "ORDER BY " + order;
		}

		Collection<Scheda_VideoBean> S_V = new LinkedList<Scheda_VideoBean>();

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			Utility.print("doRetrieveAll " + preparedStatement.toString());

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				Scheda_VideoBean bean = new Scheda_VideoBean();
				
				bean.setNome(rs.getString("Nome"));
				bean.setBrand(rs.getString("Brand"));
				bean.setQuantita(rs.getInt("Quantita"));
				bean.setPrezzo(rs.getFloat("Prezzo"));
				bean.setDescrizione(rs.getString("Descrizione"));
				bean.setID_scheda_video(rs.getString("ID_scheda_video"));
				bean.setRAM(rs.getString("RAM"));
				bean.setModello(rs.getString("Modello"));
				bean.setUtilizzo(rs.getString("Utilizzo"));
				bean.setID_prodotto(rs.getString("ID_prodotto"));

				S_V.add(bean);
			}

		} finally {
			try {
			if (preparedStatement != null)
				preparedStatement.close();
			}finally {
			if (connection != null)
				connection.close();
			}
		}

		return S_V;
	}
	
	@Override
	public Scheda_VideoBean doRetrieveByKey(String ID_scheda_video) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void doSave(Scheda_VideoBean item) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doUpdate(Scheda_VideoBean  item) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doDelete(Scheda_VideoBean  item) throws SQLException {
		// TODO Auto-generated method stub

	}

}