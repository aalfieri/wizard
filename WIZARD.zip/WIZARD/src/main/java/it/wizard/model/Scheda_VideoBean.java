package it.wizard.model;

import java.io.Serializable;

public class Scheda_VideoBean extends ProductBean {

    private static final long serialVersionUID = 1L;

    
    String ID_scheda_video;
    String RAM;
    String Modello;
    String Utilizzo;
    String ID_prodotto;

    public Scheda_VideoBean() {
    	
        ID_scheda_video = "";
        RAM = "";
        Modello= "";
        Utilizzo = "";
        ID_prodotto="";
    }

    
    


	public String getID_scheda_video() {
        return ID_scheda_video;
    }

    public void setID_scheda_video(String iD_scheda_video) {
        ID_scheda_video = iD_scheda_video;
    }


    public String getRAM() {
        return RAM;
    }


    public void setRAM(String rAM) {
        RAM = rAM;
    }


    public String getModello() {
        return Modello;
    }

    public void setModello(String modello) {
        Modello = modello;
    }


    public String getUtilizzo() {
        return Utilizzo;
    }


    public void setUtilizzo(String utilizzo) {
        Utilizzo = utilizzo;
    }


    public String getID_prodotto() {
        return ID_prodotto;
    }


    public void setID_prodotto(String iD_prodotto) {
        ID_prodotto = iD_prodotto;
    }


    @Override
    public boolean equals(Object other) {
        return this.getID_scheda_video() == ((Scheda_VideoBean) other).getID_scheda_video();
    }

    @Override
    public String toString() {
        return ID_scheda_video+" (" +RAM +") "+Modello + ", "+ ID_prodotto;
    }
}