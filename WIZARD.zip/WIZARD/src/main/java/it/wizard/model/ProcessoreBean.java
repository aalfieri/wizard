package it.wizard.model;

import java.io.Serializable;

public class ProcessoreBean extends ProductBean{

    private static final long serialVersionUID = 1L;

   
    String ID_processore;
    String Socket_;
    String Serie;
    String ID_prodotto;
  
    

    public ProcessoreBean() {
    	
        ID_processore = "";
        Socket_ = "";
        Serie= "";
        ID_prodotto="";
        
    }

	public String getID_processore() {
		return ID_processore;
	}



	public void setID_processore(String iD_processore) {
		ID_processore = iD_processore;
	}



	public String getSocket_() {
		return Socket_;
	}



	public void setSocket_(String socket_) {
		Socket_ = socket_;
	}



	public String getSerie() {
		return Serie;
	}



	public void setSerie(String serie) {
		Serie = serie;
	}



	public String getID_prodotto() {
		return ID_prodotto;
	}



	public void setID_prodotto(String iD_prodotto) {
		ID_prodotto = iD_prodotto;
	}



	@Override
    public boolean equals(Object other) {
        return this.getID_processore() == ((ProcessoreBean) other).getID_processore();
    }

    @Override
    public String toString() {
        return ID_processore+" (" + Socket_ +") "+Serie + ", "+ ID_prodotto+ ", "+ Prezzo;
    }
}