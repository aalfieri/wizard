package it.wizard.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import javax.sql.DataSource;

import it.wizard.utils.Utility;

public class CaseModelDS implements CaseModel<CaseBean> {

	
	@Override
	public Collection<CaseBean> doRetrieveAll(String order) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String selectSQL = "SELECT * FROM CASEpc,PRODOTTO where PRODOTTO.ID_prodotto=CASEpc.ID_prodotto";

		if (order != null && !order.equals("")) {
			selectSQL += "ORDER BY " + order;
		}

		Collection<CaseBean> casepc = new LinkedList<CaseBean>();

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			Utility.print("doRetrieveAll " + preparedStatement.toString());

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				CaseBean bean = new CaseBean();

				bean.setNome(rs.getString("Nome"));
				bean.setBrand(rs.getString("Brand"));
				bean.setPrezzo(rs.getFloat("Prezzo"));
				bean.setDescrizione(rs.getString("Descrizione"));
				bean.setID_case(rs.getString("ID_case"));
				bean.setTipo(rs.getString("Tipo"));
				bean.setFattore_forma(rs.getString("Fattore_forma"));
				bean.setColore(rs.getString("Colore"));
				bean.setID_prodotto(rs.getString("ID_prodotto"));

				casepc.add(bean);
			}

		} finally {
			try {
			if (preparedStatement != null)
				preparedStatement.close();
			}finally {
			if (connection != null)
				connection.close();
			}
		}

		return casepc;
	}
	

	@Override
	public void doSave(CaseBean item) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doUpdate(CaseBean item) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doDelete(CaseBean item) throws SQLException {
		// TODO Auto-generated method stub

	}
	
	@Override
	public CaseBean doRetrieveByKey(String ID_case) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}