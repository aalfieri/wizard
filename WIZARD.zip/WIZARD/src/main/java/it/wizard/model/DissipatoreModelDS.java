package it.wizard.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import javax.sql.DataSource;

import it.wizard.utils.Utility;

public class DissipatoreModelDS implements DissipatoreModel<DissipatoreBean> {


	@Override
	public Collection<DissipatoreBean> doRetrieveAll(String order) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String selectSQL = "SELECT * FROM DISSIPATORE,PRODOTTO WHERE PRODOTTO.ID_prodotto=DISSIPATORE.ID_prodotto";

		if (order != null && !order.equals("")) {
			selectSQL += "ORDER BY " + order;
		}

		Collection<DissipatoreBean> dissipatore = new LinkedList<DissipatoreBean>();

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			Utility.print("doRetrieveAll " + preparedStatement.toString());

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				DissipatoreBean bean = new DissipatoreBean();

				bean.setNome(rs.getString("Nome"));
				bean.setBrand(rs.getString("Brand"));
				bean.setQuantita(rs.getInt("Quantita"));
				bean.setPrezzo(rs.getFloat("Prezzo"));
				bean.setDescrizione(rs.getString("Descrizione"));
				bean.setID_dissipatore(rs.getString("ID_dissipatore"));
				bean.setTipo(rs.getString("Tipo"));
				bean.setCPU_compatibile(rs.getString("CPU_compatibile"));
				bean.setSocket_compatibile(rs.getString("Socket_compatibile"));
				bean.setNum_ventole(rs.getInt("Num_ventole"));
				bean.setSpeed_ventole(rs.getString("Speed_ventole"));
				bean.setID_prodotto(rs.getString("ID_prodotto"));
				dissipatore.add(bean);
			}

		} finally {
			try {
			if (preparedStatement != null)
				preparedStatement.close();
			}finally {
			if (connection != null)
				connection.close();
			}
		}

		return dissipatore;
	}

	@Override
	public void doSave(DissipatoreBean item) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doUpdate(DissipatoreBean item) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doDelete(DissipatoreBean item) throws SQLException {
		// TODO Auto-generated method stub

	}


	@Override
	public DissipatoreBean doRetrieveByKey(String ID_dissipatore) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
}
