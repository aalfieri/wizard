package it.wizard.model;

import java.io.Serializable;

public class CaseBean extends ProductBean {

	private static final long serialVersionUID = 1L;
	
	
	
	
	String ID_case;
	String Tipo;
	String Fattore_forma;
	String Colore;
	String ID_prodotto;
	
	public CaseBean() {
		
		ID_case = "";
		Tipo = "";
		Fattore_forma = "";
		Colore = "";
		ID_prodotto = "";
	}
	

	


	public String getID_case() {
		return ID_case;
	}

	public void setID_case(String iD_case) {
		ID_case = iD_case;
	}

	public String getTipo() {
		return Tipo;
	}

	public void setTipo(String tipo) {
		Tipo = tipo;
	}

	public String getFattore_forma() {
		return Fattore_forma;
	}

	public void setFattore_forma(String fattore_forma) {
		Fattore_forma = fattore_forma;
	}

	public String getColore() {
		return Colore;
	}

	public void setColore(String colore) {
		Colore = colore;
	}

	public String getID_prodotto() {
		return ID_prodotto;
	}

	public void setID_prodotto(String iD_prodotto) {
		ID_prodotto = iD_prodotto;
	}
	
	@Override
	public boolean equals(Object other) {
		return this.getID_case() == ((CaseBean) other).getID_case();
	}
	
	@Override
	public String toString() {
		return ID_case +" ," + Tipo +", "+ Fattore_forma + ", " + Colore +", "  + ID_prodotto;
	}

}
