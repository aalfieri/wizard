package it.wizard.model;

import java.beans.Beans;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import javax.sql.DataSource;

import it.wizard.utils.Utility;

public class ProcessoreModelDS implements ProcessoreModel<ProcessoreBean> {

	@Override
	public Collection<ProcessoreBean> doRetrieveAll(String order) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String selectSQL = "SELECT * FROM PROCESSORE,PRODOTTO where PRODOTTO.ID_prodotto=PROCESSORE.ID_prodotto";

		if (order != null && !order.equals("")) {
			selectSQL += "ORDER BY " + order;
		}

		Collection<ProcessoreBean> pro = new LinkedList<ProcessoreBean>();

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			Utility.print("doRetrieveAll " + preparedStatement.toString());

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				ProcessoreBean bean = new ProcessoreBean();
				bean.setNome(rs.getString("Nome"));
				bean.setBrand(rs.getString("Brand"));
				bean.setQuantita(rs.getInt("Quantita"));
				bean.setDescrizione(rs.getString("Descrizione"));
				bean.setID_processore(rs.getString("ID_processore"));
				bean.setSocket_(rs.getString("Socket_"));
				bean.setSerie(rs.getString("Serie"));
				bean.setID_prodotto(rs.getString("ID_prodotto"));
				bean.setPrezzo(rs.getFloat("Prezzo"));
				pro.add(bean);
			}

		} finally {
			try {
			if (preparedStatement != null)
				preparedStatement.close();
			}finally {
			if (connection != null)
				connection.close();
			}
		}

		return pro;
	}
	
	@Override
	public ProcessoreBean doRetrieveByKey(String ID_processore) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void doSave(ProcessoreBean item) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doUpdate(ProcessoreBean item) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doDelete(ProcessoreBean  item) throws SQLException {
		// TODO Auto-generated method stub

	}

}
