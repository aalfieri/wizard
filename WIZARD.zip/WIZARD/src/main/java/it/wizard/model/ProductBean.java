package it.wizard.model;

import java.io.Serializable;

public class ProductBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	String ID_prodotto;
	String ID_magazzino;
	String Nome;
	String Brand;
	int Quantita;
	float Prezzo;
	String Descrizione;
	
	public ProductBean() {
		ID_prodotto = "";
		ID_magazzino = "";
		Nome = "";
		Brand = "";
		Quantita = 0;
		Prezzo = 0;
		Descrizione = "";
	}

	public String getID_prodotto() {
		return ID_prodotto;
	}

	public void setID_prodotto(String iD_prodotto) {
		ID_prodotto = iD_prodotto;
	}

	public String getID_magazzino() {
		return ID_magazzino;
	}

	public void setID_magazzino(String iD_magazzino) {
		ID_magazzino = iD_magazzino;
	}

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public String getBrand() {
		return Brand;
	}

	public void setBrand(String brand) {
		Brand = brand;
	}

	public int getQuantita() {
		return Quantita;
	}

	public void setQuantita(int quantita) {
		Quantita = quantita;
	}

	public float getPrezzo() {
		return Prezzo;
	}

	public void setPrezzo(float prezzo) {
		Prezzo = prezzo;
	}

	public String getDescrizione() {
		return Descrizione;
	}

	public void setDescrizione(String descrizione) {
		Descrizione = descrizione;
	}
	
	@Override
	public boolean equals(Object other) {
		return this.getID_prodotto() == ((ProductBean) other).getID_prodotto();
	}
	
	@Override
	public String toString() {
		return Nome +" (" + ID_prodotto +") "+ Brand + ", " + Prezzo +", "+ Quantita + ", " + Descrizione;
	}
}
