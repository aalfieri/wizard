package it.wizard.model;

import java.io.Serializable;

public class SchedaMadreBean extends ProductBean {


	private static final long serialVersionUID = 1L;
	

	
	String ID_scheda_madre;
	String Socket_;
	String Forma;
	String ChipSet;
	String CPUcompatibile;
	String Utilizzo;
	
	
	public SchedaMadreBean() {
		
		ID_scheda_madre = "";
		Socket_= "";
		Forma  = "";
		ChipSet = "";
		CPUcompatibile = "";
		Utilizzo = "";
		ID_prodotto = "";
		
		
	}


	public String getID_scheda_madre() {
		return ID_scheda_madre;
	}

	public void setID_scheda_madre(String iD_scheda_madre) {
		ID_scheda_madre = iD_scheda_madre;
	}

	public String getSocket_() {
		return Socket_;
	}

	public void setSocket_(String socket_) {
		Socket_ = socket_;
	}

	public String getForma() {
		return Forma;
	}

	public void setForma(String forma) {
		Forma = forma;
	}

	public String getChipSet() {
		return ChipSet;
	}

	public void setChipSet(String chipSet) {
		ChipSet = chipSet;
	}

	public String getCPUcompatibile() {
		return CPUcompatibile;
	}

	public void setCPUcompatibile(String cPUcompatibile) {
		CPUcompatibile = cPUcompatibile;
	}

	public String getUtilizzo() {
		return Utilizzo;
	}

	public void setUtilizzo(String utilizzo) {
		Utilizzo = utilizzo;
	}

	public String getID_prodotto() {
		return ID_prodotto;
	}

	public void setID_prodotto(String iD_prodotto) {
		ID_prodotto = iD_prodotto;
	}

	@Override
	public boolean equals(Object other) {
		return this.getID_scheda_madre() == ((SchedaMadreBean) other).getID_scheda_madre();
	}
	
	@Override
	public String toString() {
		return ID_scheda_madre +", " + Socket_ +", " + Forma +", " + ChipSet +", " + CPUcompatibile + ", " + Utilizzo + ", " + ID_prodotto+ ", "+ Prezzo;
	}
	
}
