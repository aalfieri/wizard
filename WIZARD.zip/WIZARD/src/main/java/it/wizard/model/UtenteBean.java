package it.wizard.model;

import java.io.Serializable;

public class UtenteBean implements Serializable {

    private static final long serialVersionUID = 1L;

    int ID_utente;
    String Nome;
    String Cognome;
    String Data_nascita;
    String Num_telefono;
    String Indirizzo;
    String Città;
    int Tipologia;
	String Username;
    String Password_;
    Carrello carrello;
    
    

	public UtenteBean() {
        ID_utente = -1;
        Nome ="";
        Cognome ="";
        Data_nascita="";
        Num_telefono="";
        Indirizzo="";
        Città ="";
        Tipologia = -1;
        Username ="";
        Password_="";
   
    }

    public int getID_utente() {
        return ID_utente;
    }

    public void setID_utente(int iD_utente) {
        ID_utente = iD_utente;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getCognome() {
        return Cognome;
    }

    public void setCognome(String cognome) {
        Cognome = cognome;
    }


    public String getData_nascita() {
		return Data_nascita;
	}

	public void setData_nascita(String data_nascita) {
		Data_nascita = data_nascita;
	}

	public String getNum_telefono() {
        return Num_telefono;
    }

    public void setNum_telefono(String num_telefono) {
        Num_telefono = num_telefono;
    }

    public String getCittà() {
        return Città;
    }

    public void setCittà(String città) {
        Città = città;
    }
    
    public int getTipologia() {
		return Tipologia;
	}

	public void setTipologia(int tipologia) {
		Tipologia = tipologia;
	}

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getPassword_() {
        return Password_;
    }

    public void setPassword_(String password_) {
        Password_ = password_;
    }
    
    
    
    public String getIndirizzo() {
		return Indirizzo;
	}

	public void setIndirizzo(String indirizzo) {
		Indirizzo = indirizzo;
	}

	@Override
    public boolean equals(Object other) {
        return this.getID_utente() == ((UtenteBean) other).getID_utente();
    }
    
    

}
