package it.wizard.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import javax.sql.DataSource;

import it.wizard.utils.Utility;

public class VentolaModelDS implements VentolaModel<VentolaBean> {


	@Override
	public Collection<VentolaBean> doRetrieveAll(String order) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String selectSQL = "SELECT * FROM VENTOLA,PRODOTTO where PRODOTTO.ID_prodotto=VENTOLA.ID_prodotto";

		if (order != null && !order.equals("")) {
			selectSQL += "ORDER BY " + order;
		}

		Collection<VentolaBean> ventola = new LinkedList<VentolaBean>();

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			Utility.print("doRetrieveAll " + preparedStatement.toString());

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				VentolaBean bean = new VentolaBean();

				bean.setNome(rs.getString("Nome"));
				bean.setBrand(rs.getString("Brand"));
				bean.setQuantita(rs.getInt("Quantita"));
				bean.setPrezzo(rs.getFloat("Prezzo"));
				bean.setDescrizione(rs.getString("Descrizione"));
				bean.setID_ventola(rs.getString("ID_ventola"));
				bean.setTipo(rs.getString("Tipo"));
				bean.setRGB(rs.getString("RGB"));
				bean.setRumore(rs.getString("Rumore"));
				bean.setVelocita(rs.getString("Velocita"));
				bean.setGrandezza(rs.getString("Grandezza"));
				bean.setID_prodotto(rs.getString("ID_prodotto"));

				ventola.add(bean);
			}

		} finally {
			try {
			if (preparedStatement != null)
				preparedStatement.close();
			}finally {
			if (connection != null)
				connection.close();
			}
		}

		return ventola;
	}
	
	
	@Override
	public void doSave(VentolaBean item) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doUpdate(VentolaBean item) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doDelete(VentolaBean item) throws SQLException {
		// TODO Auto-generated method stub

	}
	@Override
	public VentolaBean doRetrieveByKey(String ID_ventola) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}
