package it.wizard.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Collection;

import javax.sql.DataSource;

public class RegistrazioneModel implements InterfacciaDAO1 <UtenteBean> {
	
	
	public RegistrazioneModel() {
		
	}
	
	@Override
	public UtenteBean doRetrieveByKey(String code) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<UtenteBean> doRetriveAll(String order) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void doSave(UtenteBean item) throws SQLException {
		
	        Connection connection = null; //creo connessione 
	        PreparedStatement preparedStatement = null;
	        String UpdateSQL = "Insert into UTENTE (Nome,Cognome,Data_nascita,Num_telefono,Indirizzo,Città,Tipologia,Username,Password) values "
	        		+ "('"+item.getNome()+"'"
	        		+ ",'"+item.getCognome()+"','"+item.getData_nascita()+
	        		"','"+item.getNum_telefono()+"','"+item.getIndirizzo()+"','"+item.getCittà()+"','"+item.getTipologia()+"','"+item.getUsername()
	        		+"','"+item.getPassword_()+"');";
	        
	        try
	        {
	        	connection = DriverManagerConnectionPool.getConnection();
				preparedStatement = connection.prepareStatement(UpdateSQL);
	            preparedStatement.executeUpdate();
	        }
	        finally { //rilasiamo tutte le risorse che abbiamo
	            try {
	            if(preparedStatement != null)
	                preparedStatement.close();
	            } finally {
	            if(connection != null)
	                connection.close();
	            }
	        }
	
	}

	@Override
	public void doUpdate(it.wizard.model.UtenteBean item) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doDelete(it.wizard.model.UtenteBean item) throws SQLException {
		// TODO Auto-generated method stub
		
	}

}
