package it.wizard.model;

import java.io.Serializable;

public class VentolaBean extends ProductBean{

	private static final long serialVersionUID = 1L;

	
	String ID_ventola;
	String Tipo;
	String RGB;
	String Rumore;
	String Velocita;
	String Grandezza;
	String ID_prodotto;
	
	public VentolaBean() {
		
		ID_ventola = "";
		Tipo = "";
		RGB = "";
		Rumore = "";
		Velocita = "";
		Grandezza = "";
		ID_prodotto = "";
	}

	
	
	
	public String getID_ventola() {
		return ID_ventola;
	}

	public void setID_ventola(String iD_ventola) {
		ID_ventola = iD_ventola;
	}

	public String getTipo() {
		return Tipo;
	}

	public void setTipo(String tipo) {
		Tipo = tipo;
	}

	public String getRGB() {
		return RGB;
	}

	public void setRGB(String rGB) {
		RGB = rGB;
	}

	public String getRumore() {
		return Rumore;
	}

	public void setRumore(String rumore) {
		Rumore = rumore;
	}

	public String getVelocita() {
		return Velocita;
	}

	public void setVelocita(String velocita) {
		Velocita = velocita;
	}

	public String getGrandezza() {
		return Grandezza;
	}

	public void setGrandezza(String grandezza) {
		Grandezza = grandezza;
	}

	public String getID_prodotto() {
		return ID_prodotto;
	}

	public void setID_prodotto(String iD_prodotto) {
		ID_prodotto = iD_prodotto;
	}
	
	@Override
	public boolean equals(Object other) {
		return this.getID_ventola() == ((VentolaBean) other).getID_ventola();
	}
	
	@Override
	public String toString() {
		return ID_ventola +", " + Tipo + ", " + RGB + ", " + Rumore + ", " + Velocita + ", " + Grandezza + "," + ID_prodotto;  
	}
}