package it.wizard.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import javax.sql.DataSource;

import it.wizard.utils.Utility;

public class SchedaReteModelDS implements SchedaReteModel<SchedaReteBean> {


	
	@Override
	public Collection<SchedaReteBean> doRetrieveAll(String order) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String selectSQL = "SELECT * FROM SCHEDA_RETE,PRODOTTO where PRODOTTO.ID_prodotto=SCHEDA_RETE.ID_prodotto";

		if (order != null && !order.equals("")) {
			selectSQL += "ORDER BY " + order;
		}

		Collection<SchedaReteBean> scheda_rete = new LinkedList<SchedaReteBean>();

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			Utility.print("doRetrieveAll " + preparedStatement.toString());

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				SchedaReteBean bean = new SchedaReteBean();

				bean.setNome(rs.getString("Nome"));
				bean.setBrand(rs.getString("Brand"));
				bean.setQuantita(rs.getInt("Quantita"));
				bean.setPrezzo(rs.getFloat("Prezzo"));
				bean.setDescrizione(rs.getString("Descrizione"));
				bean.setID_scheda_rete(rs.getString("ID_scheda_rete"));
				bean.setTipo(rs.getString("Tipo"));
				bean.setVelocita(rs.getString("Velocita"));
				bean.setID_prodotto(rs.getString("ID_prodotto"));
				scheda_rete.add(bean);
			}

		} finally {
			try {
			if (preparedStatement != null)
				preparedStatement.close();
			}finally {
			if (connection != null)
				connection.close();
			}
		}

		return scheda_rete;
	
	}

	@Override
	public void doSave(SchedaReteBean item) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doUpdate(SchedaReteBean item) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doDelete(SchedaReteBean item) throws SQLException {
		// TODO Auto-generated method stub

	}
	
	@Override
	public SchedaReteBean doRetrieveByKey(String ID_scheda_rete) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}
