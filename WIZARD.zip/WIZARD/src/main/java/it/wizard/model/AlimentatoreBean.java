package it.wizard.model;

import java.io.Serializable;

public class AlimentatoreBean extends ProductBean {

	private static final long serialVersionUID = 1L;

	String ID_alimentatore;
	String Potenza;
	String Tipo;
	String Serie;
	String ID_prodotto;
	
	public AlimentatoreBean() {
		
		ID_alimentatore = "";
		Potenza = "";
		Tipo = "";
		Serie = "";
		ID_prodotto = "";
	}

	
	
	public String getID_alimentatore() {
		return ID_alimentatore;
	}

	public void setID_alimentatore(String iD_alimentatore) {
		ID_alimentatore = iD_alimentatore;
	}

	public String getPotenza() {
		return Potenza;
	}

	public void setPotenza(String potenza) {
		Potenza = potenza;
	}

	public String getTipo() {
		return Tipo;
	}

	public void setTipo(String tipo) {
		Tipo = tipo;
	}

	public String getSerie() {
		return Serie;
	}

	public void setSerie(String serie) {
		Serie = serie;
	}

	public String getID_prodotto() {
		return ID_prodotto;
	}

	public void setID_prodotto(String iD_prodotto) {
		ID_prodotto = iD_prodotto;
	}
	
	@Override
	public boolean equals(Object other) {
		return this.getID_alimentatore() == ((AlimentatoreBean) other).getID_alimentatore();
	}
	
	@Override
	public String toString() {
		return ID_alimentatore +", " + Potenza + ", " + Tipo + ", " + Serie + ", " + ID_prodotto;  
	}
}