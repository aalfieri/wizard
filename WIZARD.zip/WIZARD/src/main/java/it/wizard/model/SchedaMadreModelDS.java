package it.wizard.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import javax.sql.DataSource;

import it.wizard.utils.Utility;

public class SchedaMadreModelDS implements SchedaMadreModel<SchedaMadreBean> {
	

	@Override
	public Collection<SchedaMadreBean> doRetrieveAll(String order) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String selectSQL = "SELECT * FROM SCHEDA_MADRE,PRODOTTO where PRODOTTO.ID_prodotto=SCHEDA_MADRE.ID_prodotto";

		if (order != null && !order.equals("")) {
			selectSQL += "ORDER BY " + order;
		}

		Collection<SchedaMadreBean> scheda_madres = new LinkedList<SchedaMadreBean>();

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			Utility.print("doRetrieveAll " + preparedStatement.toString());

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				SchedaMadreBean bean = new SchedaMadreBean();

				bean.setNome(rs.getString("Nome"));
				bean.setBrand(rs.getString("Brand"));
				bean.setQuantita(rs.getInt("Quantita"));
				bean.setDescrizione(rs.getString("Descrizione"));
				bean.setID_scheda_madre(rs.getString("ID_scheda_madre"));
				bean.setSocket_(rs.getString("Socket_"));
				bean.setForma(rs.getString("Forma"));
				bean.setChipSet(rs.getString("ChipSet"));
				bean.setCPUcompatibile(rs.getString("CPUcompatibile"));
				bean.setUtilizzo(rs.getString("Utilizzo"));
				bean.setID_prodotto(rs.getString("ID_prodotto"));
				bean.setPrezzo(rs.getFloat("Prezzo"));

				scheda_madres.add(bean);
			}

		} finally {
			try {
			if (preparedStatement != null)
				preparedStatement.close();
			}finally {
			if (connection != null)
				connection.close();
			}
		}

		return scheda_madres;
	
	}

	@Override
	public void doSave(SchedaMadreBean item) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doUpdate(SchedaMadreBean item) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doDelete(SchedaMadreBean item) throws SQLException {
		// TODO Auto-generated method stub

	}
	
	@Override
	public SchedaMadreBean doRetrieveByKey(String ID_scheda_madre) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}
