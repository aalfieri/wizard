package it.wizard.model;

import java.io.Serializable;

public class SchedaReteBean extends ProductBean{

	private static final long serialVersionUID = 1L;

	
	String ID_scheda_rete;
	String Tipo;
	String Velocita;
	String ID_prodotto;
	
	public SchedaReteBean() {
		
		ID_scheda_rete ="";
		Tipo = "";
		Velocita ="";
		ID_prodotto ="";
	}

	
	

	public String getID_scheda_rete() {
		return ID_scheda_rete;
	}

	public void setID_scheda_rete(String iD_scheda_rete) {
		ID_scheda_rete = iD_scheda_rete;
	}

	public String getTipo() {
		return Tipo;
	}

	public void setTipo(String tipo) {
		Tipo = tipo;
	}

	public String getVelocita() {
		return Velocita;
	}

	public void setVelocita(String velocita) {
		Velocita = velocita;
	}

	public String getID_prodotto() {
		return ID_prodotto;
	}

	public void setID_prodotto(String iD_prodotto) {
		ID_prodotto = iD_prodotto;
	}
	
	@Override
	public boolean equals(Object other) {
		return this.getID_scheda_rete() == ((SchedaReteBean) other).getID_scheda_rete();
	}
	
	@Override
	public String toString() {
		return ID_scheda_rete +", " + Tipo + ", " + Velocita + ", " + ID_prodotto;  
	}
}
