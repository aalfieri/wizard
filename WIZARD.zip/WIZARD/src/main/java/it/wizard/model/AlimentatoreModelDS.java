package it.wizard.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import javax.sql.DataSource;

import it.wizard.utils.Utility;

public class AlimentatoreModelDS implements AlimentatoreModel<AlimentatoreBean> {
	

	@Override
	public Collection<AlimentatoreBean> doRetrieveAll(String order) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String selectSQL = "SELECT * FROM ALIMENTATORE,PRODOTTO where PRODOTTO.ID_prodotto=ALIMENTATORE.ID_prodotto";

		if (order != null && !order.equals("")) {
			selectSQL += "ORDER BY " + order;
		}

		Collection<AlimentatoreBean> alimentatore = new LinkedList<AlimentatoreBean>();

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			Utility.print("doRetrieveAll " + preparedStatement.toString());

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				AlimentatoreBean bean = new AlimentatoreBean();

				bean.setNome(rs.getString("Nome"));
				bean.setBrand(rs.getString("Brand"));
				bean.setQuantita(rs.getInt("Quantita"));
				bean.setPrezzo(rs.getFloat("Prezzo"));
				bean.setDescrizione(rs.getString("Descrizione"));
				bean.setID_alimentatore(rs.getString("ID_alimentatore"));
				bean.setPotenza(rs.getString("Potenza"));
				bean.setTipo(rs.getString("Tipo"));
				bean.setSerie(rs.getString("Serie"));
				bean.setID_prodotto(rs.getString("ID_prodotto"));

				alimentatore.add(bean);
			}

		} finally {
			try {
			if (preparedStatement != null)
				preparedStatement.close();
			}finally {
			if (connection != null)
				connection.close();
			}
		}

		return alimentatore;
	}

	@Override
	public void doSave(AlimentatoreBean item) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doUpdate(AlimentatoreBean item) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doDelete(AlimentatoreBean item) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public AlimentatoreBean doRetrieveByKey(String ID_alimentatore) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}
