package it.wizard.model;

import java.io.Serializable;

public class RAMbean extends ProductBean {

    private static final long serialVersionUID = 1L;

    String ID_prodotto;
    String ID_ram;
    String Memoria;
    String Forma;
    String Latenza;
    String Tipo;
    String Velocita;
    String Modello;


    public RAMbean() {
        ID_prodotto="";
        ID_ram = "";
        Memoria = "";
        Forma= "";
        Latenza = "";
        Tipo = "";
        Velocita = "";
        Modello= "";
    }

    public String getID_prodotto() {
        return ID_prodotto;
    }



    public void setID_prodotto(String iD_prodotto) {
        ID_prodotto = iD_prodotto;
    }
    

    public String getID_ram() {
        return ID_ram;
    }



    public void setID_ram(String iD_ram) {
        ID_ram = iD_ram;
    }



    public String getMemoria() {
        return Memoria;
    }



    public void setMemoria(String memoria) {
        Memoria = memoria;
    }



    public String getForma() {
        return Forma;
    }



    public void setForma(String forma) {
        Forma = forma;
    }



    public String getLatenza() {
        return Latenza;
    }



    public void setLatenza(String latenza) {
        Latenza = latenza;
    }



    public String getTipo() {
        return Tipo;
    }



    public void setTipo(String tipo) {
        Tipo = tipo;
    }



    public String getVelocita() {
        return Velocita;
    }



    public void setVelocita(String velocita) {
        Velocita = velocita;
    }



    public String getModello() {
        return Modello;
    }



    public void setModello(String modello) {
        Modello = modello;
    }

    @Override
    public boolean equals(Object other) {
        return this.getID_ram() == ((RAMbean) other).getID_ram();
    }

    @Override
    public String toString() {
        return ID_ram +" (" + Memoria +") "+ Forma + ", " + Latenza +", "+ Tipo + ", " + Velocita +","+ Modello + ","+ ID_prodotto;
    }
}