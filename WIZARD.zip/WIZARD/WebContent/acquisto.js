function aggiungiAcquisto(id_prodotto,prefisso){
	
	$.ajax({
					type:"POST",
					url:prefisso+"/CarrelloControl",
						data:{
						action: "aggiungi",
						id_prodotto:id_prodotto
							},
						success:alert("Prodotto aggiunto al carrello "),
						
						error:function (xhr, status, error){
						alert(xhr.status)
						}
				
			}
			)
}




function eliminaAcquisto(id_prodotto,prefisso){
    $.ajax({
                    type:"POST",
                    url:prefisso+"/CarrelloControl",
                        data:{
                        action: "elimina",
                        id_prodotto:id_prodotto
                            },
                        success:alert("prodotto eliminato dal carrello"),


                        error:function (xhr, status, error){
                        alert(xhr.status)
                        }

            }
            )
}

