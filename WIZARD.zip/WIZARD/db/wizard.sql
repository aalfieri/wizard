	DROP DATABASE IF EXISTS storeproduct;
    
    CREATE DATABASE storeproduct;
    USE storeproduct;
    
    DROP USER IF EXISTS 'wizard'@'localhost';
    CREATE USER 'wizard'@'localhost' IDENTIFIED BY 'wizard';
    GRANT ALL ON storeproduct.* TO 'wizard'@'localhost';
    
        CREATE TABLE UTENTE(
        ID_utente int (20) AUTO_INCREMENT ,
        Nome char (20) not null,
        Cognome char (20) not null,
        data_nascita date not null,
        Num_telefono char (20) not null,
        Indirizzo char (40) not null,
        Città char (20) not null,
        Tipologia int default 0,
        Username char (20) not null,
        Password_ char (20) not null,
        primary key(ID_utente)
        );
        
        CREATE TABLE MAGAZZINO(
        ID_magazzino char (20) not null,
        Via char (20) not null,
        Nome char (20) not null,
        Recapito_telefonico char (20) not null,
        primary key(ID_magazzino)
        );
        
		CREATE TABLE ORDINE(
        ID_ordine char (20) not null,
        ID_utente int (20) AUTO_INCREMENT ,
        Data_ordine date not null,
        primary key(ID_ordine),
		foreign key (ID_utente) references UTENTE (ID_utente) on update cascade on delete cascade
        );
        
        CREATE TABLE PRODOTTO(
        ID_prodotto char (20) not null,
        ID_magazzino char (20) not null,
        Nome char (50) not null,
        Brand char (50) not null,
        Quantita int default 0,
        Prezzo float default 0,
        Descrizione char (250),
        primary key (ID_prodotto),
        foreign key (ID_magazzino) references MAGAZZINO(ID_magazzino) on update cascade on delete cascade
        );
        
        CREATE TABLE CONTIENE(
        ID_prodotto char (20) not null,
		ID_ordine char (20) not null,
        primary key(ID_prodotto,ID_ordine),
        foreign key (ID_prodotto) references PRODOTTO (ID_prodotto)on update cascade on delete cascade,
        foreign key (ID_ordine) references ORDINE (ID_ordine)on update cascade on delete cascade
        );
        
		CREATE TABLE RAM (
        ID_ram char (20) not null,
        Memoria char (20) not null,
        Forma char (20) not null,
        Latenza char (20) not null,
        Tipo char (20) not null,
        Velocita char (20) not null,
        Modello char (20) not null,
        ID_prodotto char (20) not null,
        primary key (ID_ram),
        foreign key (ID_prodotto) references PRODOTTO (ID_prodotto)on update cascade on delete cascade
		);
        
        CREATE TABLE SCHEDA_MADRE(
        ID_scheda_madre char (20) not null,
        Socket_ char (20) not null,
        Forma char (20) not null,
        ChipSet char (20) not null,
        CPUcompatibile char (20) not null,
        Utilizzo char (20) not null,
        ID_prodotto char (20) not null,
        primary key (ID_scheda_madre),
        foreign key (ID_prodotto) references PRODOTTO (ID_prodotto)on update cascade on delete cascade
        );
        
        CREATE TABLE SCHEDA_VIDEO(
        ID_scheda_video char (20) not null,
        RAM char (20) not null,
        Modello char (20) not null,
        Utilizzo char (20) not null,
        ID_prodotto char (20) not null,
        primary key (ID_scheda_video),
        foreign key (ID_prodotto) references PRODOTTO(ID_prodotto) on update cascade on delete cascade
        );
        
        CREATE TABLE CASEpc(
        ID_case char (20) not null,
        Tipo char (20) not null,
        Fattore_forma char (20) not null,
        Colore char (20) not null,
        ID_prodotto char (20) not null,
        primary key (ID_case),
        foreign key (ID_prodotto) references PRODOTTO(ID_prodotto) on update cascade on delete cascade
        );
        
        CREATE TABLE PROCESSORE(
        ID_processore char (20) not null,
        Socket_ char (20) not null,
        Serie char (20) not null,
        ID_prodotto char (20) not null,
        primary key(ID_processore),
        foreign key (ID_prodotto) references PRODOTTO(ID_prodotto) on update cascade on delete cascade
        );
        
        CREATE TABLE ALIMENTATORE(
        ID_alimentatore char (20) not null,
        Potenza char (20) not null,
        Tipo char (20) not null,
        Serie char (20) not null,
        ID_prodotto char (20) not null,
        primary key (ID_alimentatore),
		foreign key (ID_prodotto) references PRODOTTO (ID_prodotto)on update cascade on delete cascade
        );
        
        CREATE TABLE VENTOLA(
        ID_ventola char (20) not null,
        Tipo char (20) not null,
        RGB char (2) not null,
        Rumore char (20) not null,
        Velocita char (20) not null,
        Grandezza char (20) not null,
        ID_prodotto char (20) not null,
        primary key (ID_ventola),
        foreign key (ID_prodotto) references PRODOTTO (ID_prodotto)on update cascade on delete cascade
        );
        
        CREATE TABLE SCHEDA_RETE(
        ID_scheda_rete char (20) not null,
        Tipo char (20) not null,
        Velocita char (20) not null,
        ID_prodotto char (20) not null,
        primary key (ID_scheda_rete),
        foreign key (ID_prodotto) references PRODOTTO(ID_prodotto) on update cascade on delete cascade
        );
        
        CREATE TABLE DISSIPATORE(
        ID_dissipatore char (20) not null,
        Tipo char (20) not null,
        CPU_compatibile char (20) not null,
        Socket_compatibile char (20) not null,
        Num_ventole int default 0,
        Speed_ventole char (20) not null,
        ID_prodotto char (20) not null,
        primary key (ID_dissipatore),
        foreign key (ID_prodotto) references PRODOTTO(ID_prodotto) on update cascade on delete cascade
        );
        
        CREATE TABLE RECENSIONE(
        ID_recensione char (20) not null,
        Data date not null,
        Testo char (100) not null,
        ID_utente int (20) AUTO_INCREMENT ,
        ID_prodotto char (20) not null,
        voto_stellina int default 0,
        foreign key (ID_utente) references UTENTE (ID_utente)on update cascade on delete cascade,
        foreign key (ID_prodotto) references PRODOTTO(ID_prodotto) on update cascade on delete cascade,
        primary key(ID_recensione)
        );
		
        CREATE TABLE PUNTO_VENDITA(
        P_I char (20) not null,
        Indirizzo char (20) not null,
        Nome char (20) not null,
        ID_magazzino char (20) not null,
        primary key (P_I),
        foreign key (ID_magazzino) references MAGAZZINO(ID_magazzino) on update cascade on delete cascade
        );
        
		CREATE TABLE E_DISPONIBILE(
        P_I char (20) not null,
        ID_prodotto char (20) not null,
        Disponibile char (2) not null,
        primary key (P_I, ID_prodotto),
        foreign key(P_I) references PUNTO_VENDITA(P_I) on update cascade on delete cascade,
		foreign key(ID_prodotto) references PRODOTTO(ID_prodotto) on update cascade on delete cascade
        );
        
		INSERT INTO UTENTE values (1,"Michele Pio","Voccia",'1999-12-09',"3491448370","Via Passanti, 144","Scafati",1,"michele","michele"); 
        INSERT INTO UTENTE values (2,"Mario","Rossi",'1990-11-03',"3332682178","Via Sudditi","Salerno",0,"mario","mario");
        
		INSERT INTO MAGAZZINO values ("mag1","Via Roma 1","Expert","0818507621");
        
        INSERT INTO ORDINE values ("Ordine1",2,'2021-03-03');
        
        INSERT INTO PRODOTTO values ("1","mag1","Scheda Madre B550","MSI",4,117.99,"Ottima per processori di ultima generazione");
        INSERT INTO PRODOTTO values ("2","mag1","Ram 16GB","Corsair",10,97.99,"2x8gb");
        INSERT INTO PRODOTTO values ("3","mag1","Alimentatore 750W","Corsair",15,124.88,"Bronzo 80 Gold");
        INSERT INTO PRODOTTO values ("4","mag1","Intel Core i5-11400","Intel",20,240.00,"6 core 12 thread 2.6ghz");
        INSERT INTO PRODOTTO values ("5","mag1","Scheda video msi geforce rtx 3060","Zotac",3,740.00,"Zotac Gaming GeForce RTX 3060 AMP White Edition e' una scheda grafica con capacita' di 12GB GDDR6, una porta HDMI e 3 Display Port. Interfaccia PCi-Express 4.0 x16");
		INSERT INTO PRODOTTO values ("6","mag1","Case MasterBox Q300L Mini Tower","CoolerMaster",10,46.99,"Case mini tower in plastica e acciaio che supporta configurazioni micro ATX e mini ITX.");
		INSERT INTO PRODOTTO values ("7","mag1","ARCTIC P12 - Ventola Da 120mm 1800 Giri","Artic",6,9.99,"Arctic p12, computer case, refrigeratore, 12 cm, 1800 giri / min, 0,3 son, 56,3 pdc / min arctic p12. Adatto per: computer case, tipo: refrigeratore, diametro del ventilatore: 12 cm. Colore del prodotto: nero, lunghezza cavo: 0,4 m");
        INSERT INTO PRODOTTO values ("8","mag1","TP-LINK TL-WN725N Nano Scheda di Rete Wireless","TP-LINK",40,6.97,"Il nano adattatore USB wireless N TP-LINK TL-WN725N consente di connettere un computer desktop o notebook ad una rete wireless e l'accesso ad una connessione Internet ad alta velocità. ");
        INSERT INTO PRODOTTO values ("9","mag1","Dissipatore CPU a Liquido iCUE H150i RGB Pro XT","Corsair",15,147.99,"Corsair icue h150i rgb pro xt è il sistema corsair di raffreddamento a liquido all-in-one che funziona in modo silenzioso, raffredda la cpu efficacemente ed è dotato di un radiatore da 360 mm e tre ventole corsair");


		INSERT INTO SCHEDA_MADRE values ("sm1","AM4","ATX","B550","AMD Ryzen","gaming","1");
		INSERT INTO RAM values ("r1","16GB","DIMM","CL16","Desktop Perf.","3200MHz","Vengeance LPX","2");
        INSERT INTO ALIMENTATORE values ("a1","750W","modulare","RM","3");
		INSERT INTO PROCESSORE values ("p1","LGA 1200","Core i5","4");
		INSERT INTO SCHEDA_VIDEO values ("sv1","12GB","GeForce RTX 3060","gaming","5");
        INSERT INTO CASEpc values ("c1","Mini Tower","E- Micro-ATX2","nero","6");
        INSERT INTO VENTOLA values ("v1","Statico","no","12Db","1800gps","120mm","7");
		INSERT INTO SCHEDA_RETE values ("sr1","USB","150mbps","8");
        INSERT INTO DISSIPATORE values ("d1","Raffr. a Liquido","AMD/Intel","AMD/Intel",3,"2400gpm","9");
        
        
		INSERT INTO RECENSIONE values ("rec1",'2021-03-04',"Scheda video performante,consigliata!",2,"5",5);
		
		INSERT INTO PUNTO_VENDITA values ("4673493","Via Fiorucci 26","Mega Stock","mag1");
        
        INSERT INTO E_DISPONIBILE values ("4673493","1","si");
        
       	INSERT INTO CONTIENE values ("1","Ordine1");
        INSERT INTO CONTIENE values ("2","Ordine1");
        INSERT INTO CONTIENE values ("5","Ordine1");
	